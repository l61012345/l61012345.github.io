import socket
import time
import threading
import struct
import os
class file_c():                         # 定义文件信息这一类
    def __init__(                       # 定义类的属性
            self,                     # 它的属性有：
            user_id=0,                           # 用户ID（QQ号）
            order_number=0,                      # 文件的编号
            page=0,                              # 页数
            number=0,                            # 编号
            file_location='',                    # 文件位置
            file_name='',                        # 文件名
            file_size='',                        # 文件大小
            Numtime=0,                           # 当前时间戳--从1970年一月一日到现在的秒数
    ):
        self.user_id = user_id
        self.order_number = order_number
        self.page = page
        self.file_location = file_location
        self.file_name = file_name
        self.file_size = file_size
        self.number = number
        self.Numtime = Numtime

sending_list=[]
connect_state={}
def connect_alive(sock):
    while True:
        print("caocaocao"+str(len(sending_list)))# 进入死循环
        print(len(sending_list))
        connect_state[0] = 1                                         # 连接状态标志位；0：异常；1：正常
        # print("start")
        if len(sending_list)==0:
            Massage_head = struct.pack('128sl',b'xintiao',0)         # 将字符拆成字节流，便于传输
            try:                                                     # 尝试发送文件头
                s_state = sock.send(Massage_head)
            except Exception as e:                                   # 发送异常的处理方式
                connect_state[0]=0                                   # 将连接状态标志为变为异常状态
                return
            # print('xintiao')
            add=file_c()
            sending_list.append(file_c(file_name='0',file_location='这是一条命令'))
            time.sleep(8)                                            # 程序推迟执行8秒
            continue                                                 # 不执行后续代码，重新跳到while语句开始执行
        # if len(sending_list) != 0:
            # print(sending_list[0].file_name)
            # print(sending_list[0].file_location)
        if sending_list[0].file_name == '0':                         # 判断要发送的是命令还是文件
            print(sending_list[0].file_name)
            print(sending_list[0].file_location)
            file_head = struct.pack('128sl', sending_list[0].file_location.encode(),1)  # 将文件命令传给file_head
            sock.send(file_head)                                     # 发送文件命令
            print(file_head)                                         # 打印发送的命令
            del sending_list[0]                                        # 删除发送列表
            continue                                                   # 不执行后续代码，重新跳到while语句开始执行
        if sending_list[0].file_name == '1':                         # 判断要发送的是命令还是文件
            print(sending_list[0].file_name)
            print(sending_list[0].file_location)
            file_head = struct.pack('128sl', sending_list[0].file_location.encode(),2)  # 将文件命令传给file_head
            sock.send(file_head)                                     # 发送文件命令
            print(file_head)                                         # 打印发送的命令
            del sending_list[0]                                        # 删除发送列表
            continue                                                   # 不执行后续代码，重新跳到while语句开始执行
        if sending_list[0].file_location[-3:]=='pdf':                  # 判断要发送的文件是否为*pdf格式
            file_head = struct.pack('128sl', os.path.basename(sending_list[0].file_location).encode(),
                                    os.stat(sending_list[0].file_location).st_size)  # 将文件地址传给file_head
            sock.send(file_head)                                       # 发送文件
            read_file = open(sending_list[0].file_location, "rb")      # 打开文件（以二进制的格式用于只读）
            while True:                                                # 死循环
                # time.sleep(1)
                file_data = read_file.read(1024)                       # 传递文件数据
                if not file_data:                                      # 若传完，跳出循环
                    break
                sock.send(file_data)                                   # 挨个发送文件数据
            read_file.close()                                          # 关闭文件
            time.sleep(2)                                              # 程序推迟执行2秒
            del sending_list[0]                                        # 删除发送列表
            continue                                                   # 不执行后续代码，重新跳到while（668）语句开始执行
def get_connect():  # socket是两个端点程序之间的“信息通道”，程序可分布在不同的计算机上（通过网络连接），通过stocket相互发送信息
    host = socket.gethostname()  # 获取计算机的主机名
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # AF_INET = 2；SOCK_STREAM = 1
    sock.bind((host, 12345))  # 将套接字绑定到主机地址上；host：主机地址；12345：端口 （参数必须是元组的格式）
    sock.listen(5)  # 使服务器能接受连接，backlog = 5, 表示内核已经接到了连接请求但服务器还没有调用 accept； 进行处理的的连接个数最大为5
    print("服务已启动---------------")  # 打印信息
    while True:  # 阻塞式连接，被动等待连接的到来
        connection, address = sock.accept()  # 接受连接并返回(conn, address)，其中connection是新的套接字对象，可用来接受和发送对象；address是连接客户端的地址                                # 显示信息
        thread = threading.Thread(target=connect_alive, args=(
        connection,))  # 实例化Thread对象（代表一个线程）；线程启动后将调用connect_alive函数；args表示调用target时的参数元组
        time.sleep(0.1)
        print("s")
        thread.start()
get_connect()
