# This is a sample Python script
import socket
import time
import logging
import os
import struct
def sending_file(connection):
    logging.exception("建立链接")#logging是记录日志，不用在乎
    while True:
        try:#尝试执行try的内容，如果不能执行就执行except Exception as e:的内容
            file_info_size = struct.calcsize('128sl')#返回与格式字符串 format 相对应的结构的大小（亦即 pack(format, ...) 所产生的字节串对象的大小）
            buf = connection.recv(file_info_size)#接收TCP 数据，数据以字符串形式返回
            if buf:#如果buf存在
                print(buf)
                file_name, file_size = struct.unpack('128sl', buf)#以128sl的方式解包
                print(file_size)
                if file_size == 0:  # 心跳 为了维持连接，隔一段时间我们发送一个数据表示自己在线，保证连接，这种数据包成为心跳包（你还活着吗）
                    buf = None
                    logging.exception("心跳")#logging是记录日志，不用在乎
                    continue
                if file_size == 1:  # 命令
                    file_name = file_name.decode().strip('\00')
                    print(file_name)
                    buf = None
                    continue
                if file_size == 2:  # pickcode
                    pickcode = file_name.decode().strip('\00')
                    print(22222, pickcode)
                    time.sleep(20)
                    print("56")
                    buf = None
                    continue
                if file_size > 2:  # 文件
                    file_name = file_name.decode().strip('\00')

                    file_new_dir = os.path.join('receive')
                    # print(file_name, file_new_dir)
                    if not os.path.exists(file_new_dir):
                        os.makedirs(file_new_dir)

                    file_new_name = os.path.join(file_new_dir, file_name)

                    received_size = 0

                    w_file = open(file_new_name, 'wb')

                    # print("start receiving file:", file_name)

                    while not received_size >= file_size:
                        print(received_size)
                        r_data = connection.recv(1024)
                        received_size += len(r_data)
                        w_file.write(r_data)

                    w_file.close()
                    print("接收完成！\n")
                    buf = None
                    continue
        except Exception as e:
            print(e)
            return
while True:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)#定义一个sock对象
    print(socket.gethostname())
    print(socket.gethostname())
    try:
        sock.connect(("182.92.6.73", 12345))#服务器的ip地址，尝试进行连接，不成功的话就会一直卡在这里
    except Exception as e:
        print(e)
        logging.exception("失去连接")#不成功的话就会continue，后面的语句就不执行，重新try
        continue
    print(sock,'1')#成功了执行下面的函数
    sending_file(sock)#里头是个死循环，只有在失去连接时才退出，然后重复
    time.sleep(5)
